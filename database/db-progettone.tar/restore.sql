--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE progettone;
--
-- Name: progettone; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE progettone WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


\connect progettone

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aziende; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aziende (
    piva character(11) NOT NULL,
    ragionesociale character varying NOT NULL,
    email character varying(319) NOT NULL,
    telefono character(14) NOT NULL,
    indirizzo character varying NOT NULL,
    immagine character varying,
    consulente character(11) NOT NULL
);


--
-- Name: consulenti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consulenti (
    piva character(11) NOT NULL,
    ragionesociale character varying NOT NULL,
    email character varying(319) NOT NULL,
    telefono character(14) NOT NULL,
    indirizzo character varying NOT NULL,
    immagine character varying
);


--
-- Name: corsi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.corsi (
    id integer NOT NULL,
    nome character varying NOT NULL,
    prezzo double precision NOT NULL,
    descrizione character varying NOT NULL,
    durata integer NOT NULL,
    consulente character(11) NOT NULL,
    categoria character varying NOT NULL,
    posti integer NOT NULL,
    postidisponibili integer NOT NULL,
    esamefinale boolean NOT NULL,
    azienda character(11) NOT NULL
);


--
-- Name: corsi_dipendenti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.corsi_dipendenti (
    corso integer NOT NULL,
    dipendente integer NOT NULL
);


--
-- Name: corsi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.corsi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: corsi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.corsi_id_seq OWNED BY public.corsi.id;


--
-- Name: dipendenti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dipendenti (
    id integer NOT NULL,
    cf character(16) NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    data_nascita date NOT NULL,
    email character varying(319) NOT NULL,
    telefono character varying(14) NOT NULL,
    indirizzo character varying NOT NULL,
    azienda character(11) NOT NULL,
    data_assunzione date NOT NULL,
    ruolo character varying NOT NULL,
    foto character varying
);


--
-- Name: dipendenti_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dipendenti_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dipendenti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dipendenti_id_seq OWNED BY public.dipendenti.id;


--
-- Name: documenti; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documenti (
    id integer NOT NULL,
    nome character varying NOT NULL,
    url character varying NOT NULL,
    rilascio date NOT NULL,
    scadenza date NOT NULL,
    dipendente integer,
    azienda character(11),
    stato character varying NOT NULL,
    formato character varying NOT NULL
);


--
-- Name: documenti_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documenti_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documenti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documenti_id_seq OWNED BY public.documenti.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    piva character(11) NOT NULL,
    email character varying(319) NOT NULL,
    password character varying NOT NULL
);


--
-- Name: corsi id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi ALTER COLUMN id SET DEFAULT nextval('public.corsi_id_seq'::regclass);


--
-- Name: dipendenti id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti ALTER COLUMN id SET DEFAULT nextval('public.dipendenti_id_seq'::regclass);


--
-- Name: documenti id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenti ALTER COLUMN id SET DEFAULT nextval('public.documenti_id_seq'::regclass);


--
-- Data for Name: aziende; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aziende (piva, ragionesociale, email, telefono, indirizzo, immagine, consulente) FROM stdin;
\.
COPY public.aziende (piva, ragionesociale, email, telefono, indirizzo, immagine, consulente) FROM '$$PATH$$/4899.dat';

--
-- Data for Name: consulenti; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consulenti (piva, ragionesociale, email, telefono, indirizzo, immagine) FROM stdin;
\.
COPY public.consulenti (piva, ragionesociale, email, telefono, indirizzo, immagine) FROM '$$PATH$$/4898.dat';

--
-- Data for Name: corsi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.corsi (id, nome, prezzo, descrizione, durata, consulente, categoria, posti, postidisponibili, esamefinale, azienda) FROM stdin;
\.
COPY public.corsi (id, nome, prezzo, descrizione, durata, consulente, categoria, posti, postidisponibili, esamefinale, azienda) FROM '$$PATH$$/4903.dat';

--
-- Data for Name: corsi_dipendenti; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.corsi_dipendenti (corso, dipendente) FROM stdin;
\.
COPY public.corsi_dipendenti (corso, dipendente) FROM '$$PATH$$/4906.dat';

--
-- Data for Name: dipendenti; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dipendenti (id, cf, nome, cognome, data_nascita, email, telefono, indirizzo, azienda, data_assunzione, ruolo, foto) FROM stdin;
\.
COPY public.dipendenti (id, cf, nome, cognome, data_nascita, email, telefono, indirizzo, azienda, data_assunzione, ruolo, foto) FROM '$$PATH$$/4905.dat';

--
-- Data for Name: documenti; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documenti (id, nome, url, rilascio, scadenza, dipendente, azienda, stato, formato) FROM stdin;
\.
COPY public.documenti (id, nome, url, rilascio, scadenza, dipendente, azienda, stato, formato) FROM '$$PATH$$/4901.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (piva, email, password) FROM stdin;
\.
COPY public.users (piva, email, password) FROM '$$PATH$$/4907.dat';

--
-- Name: corsi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.corsi_id_seq', 2, true);


--
-- Name: dipendenti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dipendenti_id_seq', 19, true);


--
-- Name: documenti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documenti_id_seq', 4, true);


--
-- Name: aziende azienda_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aziende
    ADD CONSTRAINT azienda_pkey PRIMARY KEY (piva);


--
-- Name: aziende azienda_telefono_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aziende
    ADD CONSTRAINT azienda_telefono_key UNIQUE (telefono);


--
-- Name: aziende aziende_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aziende
    ADD CONSTRAINT aziende_email_key UNIQUE (email);


--
-- Name: consulenti consulenti_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consulenti
    ADD CONSTRAINT consulenti_email_key UNIQUE (email);


--
-- Name: consulenti consulenti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consulenti
    ADD CONSTRAINT consulenti_pkey PRIMARY KEY (piva);


--
-- Name: consulenti consulenti_telefono_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consulenti
    ADD CONSTRAINT consulenti_telefono_key UNIQUE (telefono);


--
-- Name: corsi_dipendenti corsi_dipendenti_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi_dipendenti
    ADD CONSTRAINT corsi_dipendenti_pk PRIMARY KEY (corso, dipendente);


--
-- Name: corsi corsi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi
    ADD CONSTRAINT corsi_pkey PRIMARY KEY (id);


--
-- Name: dipendenti dipendenti_cf_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti
    ADD CONSTRAINT dipendenti_cf_key UNIQUE (cf);


--
-- Name: dipendenti dipendenti_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti
    ADD CONSTRAINT dipendenti_email_key UNIQUE (email);


--
-- Name: dipendenti dipendenti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti
    ADD CONSTRAINT dipendenti_pkey PRIMARY KEY (id);


--
-- Name: dipendenti dipendenti_telefono_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti
    ADD CONSTRAINT dipendenti_telefono_key UNIQUE (telefono);


--
-- Name: documenti documenti_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documenti
    ADD CONSTRAINT documenti_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (piva);


--
-- Name: aziende aziende_consulente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aziende
    ADD CONSTRAINT aziende_consulente_fkey FOREIGN KEY (consulente) REFERENCES public.consulenti(piva) ON DELETE CASCADE;


--
-- Name: aziende aziende_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aziende
    ADD CONSTRAINT aziende_users_fk FOREIGN KEY (piva) REFERENCES public.users(piva) ON DELETE CASCADE;


--
-- Name: consulenti consulenti_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consulenti
    ADD CONSTRAINT consulenti_users_fk FOREIGN KEY (piva) REFERENCES public.users(piva) ON DELETE CASCADE;


--
-- Name: corsi corsi_azienda_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi
    ADD CONSTRAINT corsi_azienda_fk FOREIGN KEY (azienda) REFERENCES public.aziende(piva);


--
-- Name: corsi corsi_consulente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi
    ADD CONSTRAINT corsi_consulente_fkey FOREIGN KEY (consulente) REFERENCES public.consulenti(piva) ON DELETE CASCADE;


--
-- Name: corsi_dipendenti corsi_dipendenti_corso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi_dipendenti
    ADD CONSTRAINT corsi_dipendenti_corso_fkey FOREIGN KEY (corso) REFERENCES public.corsi(id) ON DELETE CASCADE;


--
-- Name: corsi_dipendenti corsi_dipendenti_dipendente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.corsi_dipendenti
    ADD CONSTRAINT corsi_dipendenti_dipendente_fkey FOREIGN KEY (dipendente) REFERENCES public.dipendenti(id) ON DELETE CASCADE;


--
-- Name: dipendenti dipendenti_azienda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dipendenti
    ADD CONSTRAINT dipendenti_azienda_fkey FOREIGN KEY (azienda) REFERENCES public.aziende(piva) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

